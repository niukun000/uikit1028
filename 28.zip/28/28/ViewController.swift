//
//  ViewController.swift
//  28
//
//  Created by Consultant on 10/30/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var textLable: UILabel!
    
    @IBOutlet weak var zero: UIButton!
    
    @IBOutlet weak var one: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        operater = ""
        res = 0.0
    }


    @IBAction func clear(_ sender: Any) {
        self.textLable.text = "0.0"
        res = 0.0
        operater = ""
    }
    
    var operater = ""
    var res = 0.0
    var flag = true
    

    @IBAction func equal(_ sender: Any) {
        operate()
        
        self.textLable.text = String(res)
        flag = true
        operater = ""
    }
    @IBAction func plus(_ sender: Any) {
        
        operate()
        operater = "+"
        self.textLable.text = String(res)
        flag = true
    }
    
    @IBAction func minus(_ sender: Any) {
        operate()
        operater = "-"
        self.textLable.text = String(res)
        flag = true
    }
    
    @IBAction func multiply(_ sender: Any) {
        operate()
        operater = "*"
        self.textLable.text = String(res)
        flag = true
    }
    
    
    @IBAction func divide(_ sender: Any) {
        operate()
        operater = "/"
        self.textLable.text = String(res)
        flag = true
    }
    
    @IBAction func zero(_ sender: Any) {
//        print("0 tapped")
        var temp : Double
        if flag == true{
            flag = false
            self.textLable.text = "0.0"
        }
        temp = Double(self.textLable.text!)!
        temp = temp * 10.0
        temp += 0
        self.textLable.text = String(temp)
        
        
    }
    
    @IBAction func one(_ sender: Any) {
//        print("0 tapped")
        var temp : Double
        if flag == true{
            flag = false
            self.textLable.text = "0.0"
        }
        temp = Double(self.textLable.text!)!
        temp = temp * 10.0
        temp += 1
        self.textLable.text = String(temp)
    }
    
    
    @IBAction func two(_ sender: Any) {
        var temp : Double
        if flag == true{
            flag = false
            self.textLable.text = "0.0"
        }
        temp = Double(self.textLable.text!)!
        temp = temp * 10.0
        temp += 2
        
        self.textLable.text = String(temp)
    }
    
    
    @IBAction func three(_ sender: Any) {
        var temp : Double
        if flag == true{
            flag = false
            self.textLable.text = "0.0"
        }
        temp = Double(self.textLable.text!)!
        temp = temp * 10.0
        temp += 3
        self.textLable.text = String(temp)
    }
    
    @IBAction func four(_ sender: Any) {
        var temp : Double
        if flag == true{
            flag = false
            self.textLable.text = "0.0"
        }
        temp = Double(self.textLable.text!)!
        temp = temp * 10.0
        temp += 4
        self.textLable.text = String(temp)
    }
    
    
    @IBAction func five(_ sender: Any) {
        var temp : Double
        if flag == true{
            flag = false
            self.textLable.text = "0.0"
        }
        temp = Double(self.textLable.text!)!
        temp = temp * 10.0
        temp += 5
        self.textLable.text = String(temp)
    }
    
    @IBAction func six(_ sender: Any) {
        var temp : Double
        if flag == true{
            flag = false
            self.textLable.text = "0.0"
        }
        temp = Double(self.textLable.text!)!
        temp = temp * 10.0
        temp += 6
        self.textLable.text = String(temp)
    }
    
    
    @IBAction func seven(_ sender: Any) {
        var temp : Double
        if flag == true{
            flag = false
            self.textLable.text = "0.0"
        }
        temp = Double(self.textLable.text!)!
        temp = temp * 10.0
        temp += 7
        self.textLable.text = String(temp)
    }
    
    @IBAction func eight(_ sender: Any) {
        var temp : Double
        if flag == true{
            flag = false
            self.textLable.text = "0.0"
        }
        temp = Double(self.textLable.text!)!
        temp = temp * 10.0
        temp += 8
        self.textLable.text = String(temp)
    }
    
    @IBAction func nine(_ sender: Any) {
        var temp : Double
        if flag == true{
            flag = false
            self.textLable.text = "0.0"
        }
        temp = Double(self.textLable.text!)!
        temp = temp * 10.0
        temp += 9
        self.textLable.text = String(temp)
    }
    
    func operate (){
        if flag == true{
            return
        }
        let num = self.textLable.text!
        if operater == "+"{
            res += Double(num)!
        }
        else if operater == "-"{
            res -= Double(num)!
        }
        else if operater == "*"{
            res *= Double(num)!
        }
        else if operater == "/"{
            res /= Double(num)!
        }
        else if operater == ""{
            res = Double(num)!
        }

    }
    
}

